<?php

return [

    'previous' => '&laquo; 上一页',
    'next' => '下一页 &raquo;',
    'showing' => '显示',
    'show' => '显示',
    'to' => '至',
    'of' => '共',

];